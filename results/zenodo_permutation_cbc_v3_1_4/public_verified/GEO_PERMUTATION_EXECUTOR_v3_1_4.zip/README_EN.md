Frozen GEO permutation executor and aggregate passing Linux preflight evidence.
No PPMI files, participant-level GEO inputs/predictions, credentials or fitted models are included.
The governing parent protocol and earlier amendments remain in the Zenodo concept DOI lineage 10.5281/zenodo.23405370.
This amendment requires public release before randomized GEO execution.
